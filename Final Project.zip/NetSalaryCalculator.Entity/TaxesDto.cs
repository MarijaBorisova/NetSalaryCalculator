﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetSalaryCalculator.Entity
{
   public class TaxesDto
    {
        const double socTax = 0.20; // till gross salary 20`004 Euro per year
        const int dep = 250; 

    }
}
