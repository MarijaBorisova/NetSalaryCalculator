﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetSalaryCalculator.Entity
{
    public class Employees
    {
        public int id { get; set; }
        public string name { get; set; }
        public string jobrole { get; set; }
        public decimal grosssalary { get; set; }

    }

}
