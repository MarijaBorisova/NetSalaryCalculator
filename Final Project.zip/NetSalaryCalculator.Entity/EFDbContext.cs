﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace NetSalaryCalculator.Entity
{
    public class EFDbContext : DbContext //component
    {
        public EFDbContext(string connectionString)//connection to database
        {
            Database.Connection.ConnectionString = connectionString;//this string for connection with database
        
        }
        
        public DbSet<Employees> Employees { get; set; }
    }
}
