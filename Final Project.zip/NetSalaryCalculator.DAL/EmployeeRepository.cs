﻿using NetSalaryCalculator.Entity;
using System;
using System.Configuration;
using System.Data.SqlClient;

namespace NetSalaryCalculator.DAL
{
    public class EmployeeRepository
    {

        public Employees GetNetSalary()
        {
            var conString = @"Server=(localdb)\mssqllocaldb; Database=EmployeesDb";
            Employees employee = new Employees();


            try
            {
                using (SqlConnection myConnection = new SqlConnection(conString))
                {
                    string oString = @"Select * FROM employees";
                    using (SqlCommand oCmd = new SqlCommand(oString, myConnection))
                    {
                        myConnection.Open();
                        using (SqlDataReader oReader = oCmd.ExecuteReader())
                        {
                            if (oReader.HasRows)
                            {
                                while (oReader.Read())
                                {

                                   employee.id = int.Parse((string)oReader["id"]);
                                   employee.name = (string)oReader["name"];
                                   employee.jobrole= (string)oReader["jobrole"];
                                   employee.grosssalary= decimal.Parse((string)oReader["grosssalary"]);


                                };
                                myConnection.Close();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return employee;
        }
    }
}
