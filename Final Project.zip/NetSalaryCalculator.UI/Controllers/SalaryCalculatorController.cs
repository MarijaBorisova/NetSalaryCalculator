﻿using Microsoft.AspNetCore.Mvc;
using NetSalaryCalculator.UI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NetSalaryCalculator.UI.Controllers
{
    public class SalaryCalculatorController : Controller
    {
        public IActionResult Index()
        {
            return View(new SalaryCalculatorViewModel());
        }
        [HttpPost]
        public IActionResult Index(SalaryCalculatorViewModel s)
        {
            if (s.grossSalary > 1600)
            {
                s.incomeTax = s.grossSalary * 23 / 100;
            }
            else if (s.grossSalary<1600)
            {
                s.incomeTax = s.grossSalary * 20 / 100;
            }

            s.netSalary = s.grossSalary - s.incomeTax;
            return View(s);
        }
    }
}
